/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tasks.MarketTask;

import java.io.IOException;

/**
 *
 * @author HP
 */
public class DataBase {
    
    public static void main(String[] args) throws IOException {
//        MainMenu m = new MainMenu();
        MainMenu.mainMenu();
    }
    
}
